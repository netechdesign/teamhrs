const DEMO = {
    BLANK_LINK: "#!",
    logo_url:window.location.origin+'/images/team_hr_logo.png'
};

export default DEMO;
