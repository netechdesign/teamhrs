
<table>
    <tbody>
    <tr><td>Published:</td>
        <td>13/07/2020</td>
    </tr>
    <tr><td>For period ending:</td>
        <td>12/07/2020</td>
    </tr>
    <tr><td></td>
        
    </tr>
    <tr><td></td>
        
    </tr>
    <tr><td></td>
        
    </tr>
    
    <tr>
       
        <td>&nbsp;</td>
        <td>
            <table style="border: 2px solid #000000;" >
                <thead>
                        <tr style="border: 2px solid #000000;">
                        <td style="background-color: #808080;"> Day</td>
                        <td style="background-color: #808080;"> </td>
                        <td valign="middle" style="text-align: center;background-color: #808080;" colspan="3"> Andrew Brydon</td>
                        <td valign="middle" style="text-align: center;background-color: #808080;" colspan="3"> Craig Barnes</td>
                        <td valign="middle" style="text-align: center;background-color: #808080;" colspan="3"> Craig Patterson</td>
                        <td valign="middle" style="text-align: center;background-color: #808080;" colspan="3">Total England</td>
                        <td valign="middle" style="text-align: center;background-color: #808080;" colspan="3">Total ScotlandTotal</td>		
                        <td valign="middle" style="text-align: center;background-color: #808080;" colspan="3">Total</td>		
                        </tr>
                        <tr>
                            <td> </td>
                            <td> </td>
                            <td>Actual</td>
                            <td>Target</td>
                            <td>Variance</td>

                            <td>Actual</td>
                            <td>Target</td>
                            <td>Variance</td>

                            <td>Actual</td>
                            <td>Target</td>
                            <td>Variance</td>

                            <td>Actual</td>
                            <td>Target</td>
                            <td>Variance</td>

                            <td>Actual</td>
                            <td>Target</td>
                            <td>Variance</td>

                            <td>Actual</td>
                            <td>Target</td>
                            <td>Variance</td>
                        </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Days worked</td>
                            <td></td>
                            <td>1</td>
                            <td>2</td>
                            <td>4</td>

                            <td>1</td>
                            <td>2</td>
                            <td>3</td>

                            <td>1</td>
                            <td>2</td>
                            <td>3</td>

                            <td>4</td>
                            <td>5</td>
                            <td>5</td>

                            <td>2</td>
                            <td>1</td>
                            <td>6</td>

                            <td>4</td>
                            <td>5</td>
                            <td>5</td>
                    </tr>

<tr>
    <td>In day installs (jobs)</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>


<tr>
    <td>OOH (jobs)</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Total installs (jobs)</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Faults In Day</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Faults OOH</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Fuels</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Jobs per man day</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Fuels per man day</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>DF %(inc aborts)</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<tr>
    <td>Abort %</td>
    <td></td>
        <td>1</td>
        <td>2</td>
        <td>4</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>1</td>
        <td>2</td>
        <td>3</td>

        <td>4</td>
        <td>5</td>
        <td>5</td>

        <td>2</td>
        <td>1</td>
        <td>6</td>

        <td>4</td>
                            <td>5</td>
                            <td>5</td>
</tr>

<!-- Engineer -->
<tr><td></td>
        
</tr>
<tr><td></td>
    
</tr>
<tr><td>12/07/2020</td>
    
</tr>
<tr><td></td></tr>
<tr>
    <td>
        <table style="border: 2px solid #000000;" >
            <thead>
                    <tr style="border: 2px solid #000000;">
                    <td style="background-color: #808080;vertical-align: top;"> WC 6 July</td>
                    <td style="background-color: #808080;"> {{ $users }}</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" > GLEN ROBSON 01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" > ANDREW BULFORD</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >LIAM FLAHERTY01</td>	
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >SIMON SNOWDON01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >RICH BRANNEN</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >BIJAN LAJEVARDI</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >DALE BURRELL</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >MICHAEL JENNINGS</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >MICHAEL SEAMAN</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >JAMIE SHEEN01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >MICHAEL BALL01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >ANDREW BRYDON01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >ANDREW MCCARROLL01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >TIM BONIFACE01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >AB Total</td>

                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >ALISTAIR CAVAN</td>	
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >CRAIG BARNES</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >JAMES MCLEAN</td>	
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >JOHN COYLE</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >RICHARD JOHNSON01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >RICHARD LANG02</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >THOMAS LEISK</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >WILLIAM FLETCHER01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >CB Total</td>

                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >CRAIG PATERSON 01</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >BRIAN BAILEY</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >CHRIS STEIN</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >GARRY GRAHAM</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >GAVIN BROWN</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >MARTIN </td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >STEPHEN</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >JONNY THOMPSON</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >SHAUN HENDERSON</td>
                    <td valign="middle" style="text-align: center;background-color: #808080;word-wrap:break-word;vertical-align: top;" >CP Total</td>
                    </tr>
                    
            </thead>
            <tbody>
                <tr>
                    <td>Days worked</td>
                        <td></td>
                        <td>1</td>
                        <td>2</td>
                        <td>4</td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>

                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>

                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>
                        <td>6</td>

                </tr>
                <tr>
                        <td>In Day Installs</td>
                        <td></td>
                        <td>1</td>
                        <td>2</td>
                        <td>4</td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>

                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>

                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>
                        <td>6</td>
                </tr>
                <tr>
                    <td>In Day Installs</td>
                    <td></td>
                        <td>1</td>
                        <td>2</td>
                        <td>4</td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>

                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>

                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>5</td>
                        <td>2</td>
                        <td>1</td>
                        <td>6</td>
                        <td>6</td>

            </tr>
            <tr>
                <td>OOH Installs</td>
                <td></td>
                <td>1</td>
                <td>2</td>
                <td>4</td>
                <td>1</td>
                <td>2</td>
                <td>3</td>
                <td>1</td>
                <td>2</td>
                <td>3</td>
                <td>4</td>
                <td>5</td>
                <td>5</td>
                <td>2</td>
                <td>1</td>
                <td>6</td>

                <td>1</td>
                <td>2</td>
                <td>3</td>
                <td>4</td>
                <td>5</td>
                <td>5</td>
                <td>2</td>
                <td>1</td>
                <td>6</td>

                <td>1</td>
                <td>2</td>
                <td>3</td>
                <td>4</td>
                <td>5</td>
                <td>5</td>
                <td>2</td>
                <td>1</td>
                <td>6</td>
                <td>6</td>
            </tr>

<tr>
    <td>Faults In Day</td>
    <td></td>
    <td>1</td>
    <td>2</td>
    <td>4</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>
    <td>6</td>
</tr>

<tr>
    <td>Faults OOH</td>
    <td></td>
    <td>1</td>
    <td>2</td>
    <td>4</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>
    <td>6</td>
</tr>

<tr>
    <td>Total</td>
    <td></td>
    <td>1</td>
    <td>2</td>
    <td>4</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>
    <td>6</td>

</tr>

<tr>
    <td>Aborts</td>
    <td></td>
    <td>1</td>
    <td>2</td>
    <td>4</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>

    <td>1</td>
    <td>2</td>
    <td>3</td>
    <td>4</td>
    <td>5</td>
    <td>5</td>
    <td>2</td>
    <td>1</td>
    <td>6</td>
    <td>6</td>
</tr>



                </tbody>
            </table> 
        </td>
    </tr>

    </tbody>
</table>
